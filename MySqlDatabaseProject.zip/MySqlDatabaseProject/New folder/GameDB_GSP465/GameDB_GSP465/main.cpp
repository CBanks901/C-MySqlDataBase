


//#include "stdafx.h"
#include <ios>
#include <iostream>
#include "sqlite3.h"
 
using namespace std;
 
int main()

{
   int rc;
   char *error;
 
   // Open Database
   cout<<"\tWelcome to Robert's GSP465 First Database.\n";
   cout << "Opening Game.db ..." << endl;
   sqlite3 *db;
   rc = sqlite3_open("Game.db", &db);
   if (rc)
   {
      cerr << "Error opening SQLite3 database: " << sqlite3_errmsg(db) << endl << endl;
      sqlite3_close(db);
      return 1;
   }
   else
   {
      cout << "Opened MyDb.db." << endl << endl;
   }
 
   // Execute SQL
   cout << "Creating GameList Table ..." << endl;
   const char *sqlCreateTable = "CREATE TABLE GameList(NameOfGame STRING);";
   rc = sqlite3_exec(db, sqlCreateTable, NULL, NULL, &error);
   if (rc)
   {
      cerr << "Error executing SQLite3 statement: " << sqlite3_errmsg(db) << endl << endl;
      sqlite3_free(error);
   }
   else
   {
      cout << "Created Table Successfully\n" << endl;
   }
 
   // Execute SQL
   cout << "Adding Games to GameList Table ..." << endl;
   const char *sqlInsert = "INSERT INTO GameList VALUES('Watchdogs');";
   rc = sqlite3_exec(db, sqlInsert, NULL, NULL, &error);
   if (rc)
   {
      cerr << "Error executing SQLite3 statement: " << sqlite3_errmsg(db) << endl << endl;
      sqlite3_free(error);
   }
   else
   {
      cout << "Inserted a value into GameList." << endl << endl;
   }
 
   // Display MyTable
   cout << "Retrieving values in GameList ..." << endl;
   const char *sqlSelect = "SELECT * FROM GameList;";
   char **results = NULL;
   int rows, columns;
   sqlite3_get_table(db, sqlSelect, &results, &rows, &columns, &error);
   if (rc)
   {
      cerr << "Error executing SQLite3 query: " << sqlite3_errmsg(db) << endl << endl;
      sqlite3_free(error);
   }
   else
   {
      // Display Table
      for (int rowCtr = 0; rowCtr <= rows; ++rowCtr)
      {
         for (int colCtr = 0; colCtr < columns; ++colCtr)
         {
            // Determine Cell Position
            int cellPosition = (rowCtr * columns) + colCtr;
 
            // Display Cell Value
            cout.width(12);
            cout.setf(ios::left);
            cout << results[cellPosition] << " ";
         }
 
         // End Line
         cout << endl;
 
         // Display Separator For Header
         if (0 == rowCtr)
         {
            for (int colCtr = 0; colCtr < columns; ++colCtr)
            {
               cout.width(12);
               cout.setf(ios::left);
               cout << "--------- ";
            }
            cout << endl;
         }
      }
   }
   sqlite3_free_table(results);
 
   // Close Database
   cout << "Closing Game.db ..." << endl;
   sqlite3_close(db);
   cout << "Closed Game.db" << endl << endl;
 
   // Wait For User To Close Program
   cout << "Please press any key to exit the program ..." << endl;
   cin.get();
 
   return 0;
}

