
// Include The Appropriate Header Files
#include "stdafx.h"
#include <windows.h>
#include <sql.h>
#include <sqlext.h>
#include <iostream>
#include <cstdio>
//#include <stdio.h>
using namespace std;
// Define The ODBC_Class Class
class ODBC_Class
{
	// Attributes
public:
	SQLHANDLE EnvHandle;
	SQLHANDLE ConHandle;
	SQLHANDLE StmtHandle;
	SQLRETURN rc;
	// Operations
public:
	ODBC_Class(); // Constructor
	~ODBC_Class(); // Destructor
	SQLRETURN ShowResults(char * title);
};
// Define The Class Constructor
ODBC_Class::ODBC_Class()
{
	// Initialize The Return Code Variable
	rc = SQL_SUCCESS;
	// Allocate An Environment Handle
	rc = SQLAllocHandle(SQL_HANDLE_ENV, SQL_NULL_HANDLE, &EnvHandle);
	// Set The ODBC Application Version To 3.x
	if (rc == SQL_SUCCESS)
		rc = SQLSetEnvAttr(EnvHandle, SQL_ATTR_ODBC_VERSION,
		(SQLPOINTER) SQL_OV_ODBC3, SQL_IS_UINTEGER);
	// Allocate A Connection Handle
	if (rc == SQL_SUCCESS)
		rc = SQLAllocHandle(SQL_HANDLE_DBC, EnvHandle, &ConHandle);
}
// Define The Class Destructor
ODBC_Class::~ODBC_Class()
{
	// Free The Connection Handle
	if (ConHandle != NULL)
		SQLFreeHandle(SQL_HANDLE_DBC, ConHandle);
	// Free The Environment Handle
	if (EnvHandle != NULL)
		SQLFreeHandle(SQL_HANDLE_ENV, EnvHandle);
}
// Define The ShowResults() Member Function
SQLRETURN ODBC_Class::ShowResults(char * element)
{
	// Declare The Local Memory Variables
	SQLCHAR textbook[100];
	SQLCHAR author[50];
	// Bind The Columns In The Result Data Set Returned To
	// Application Variables
	rc = SQLBindCol(StmtHandle, 1, SQL_C_CHAR, (SQLPOINTER) &textbook,
		sizeof(textbook), NULL);
	rc = SQLBindCol(StmtHandle, 2, SQL_C_CHAR, (SQLPOINTER) &author,
		sizeof(author), NULL);
	rc = SQLFetch(StmtHandle);
	if (rc != SQL_NO_DATA){
		cout << "The textbook for " << element << " is " << textbook << endl;
		cout << "The author is " << author << endl;
	}
	else
		cout << "The course you have requested is not found." << endl;
	// Return The ODBC API Return Code To The Calling Function
	return(rc);
}

// ODBC_Test1.cpp : Defines the entry point for the console application.
/*-----------------------------------------------------------------*/
/* The Main Function */
/*-----------------------------------------------------------------*/
int _tmain(int argc, _TCHAR* argv[])
//int main()
{
	
	// Declare The Local Memory Variables
	const rsize_t BUFF255 = 255;
	SQLRETURN rc = SQL_SUCCESS;
	SQLCHAR DBName[9] = "bookbase";
	SQLCHAR SQLStmt[BUFF255];
	char * element;
	element = new char[BUFF255];
	bool LoopActiveFlag = true;

	// Create An Instance Of The ODBC_Class Class
	ODBC_Class Example;

	// Connect To The Sample Database
	if (Example.ConHandle != NULL)
	{
		rc = SQLConnect(Example.ConHandle, DBName, SQL_NTS,
			(SQLCHAR *) "", SQL_NTS, (SQLCHAR *) "", SQL_NTS);
		while (LoopActiveFlag){ 
			// Allocate An SQL Statement Handle
			rc = SQLAllocHandle(SQL_HANDLE_STMT, Example.ConHandle,
				&Example.StmtHandle);
			if (rc == SQL_SUCCESS)
			{
				cout << "Enter a Course or 'exit' to quit):  ";
				cin.getline(element, BUFF255,'\n');
				if (strcmp(element, "exit") == 0)
				{
					LoopActiveFlag = false;
				}
				else
				{
					// Define A SELECT SQL Statement NOTE: add code to check for success of strcpy_s and strcat_s (should return 0)
					strcpy_s((char *) SQLStmt, BUFF255, "SELECT bookbase.Title, bookbase.Author_Data FROM bookbase WHERE bookbase.Course=");
					strcat_s((char *) SQLStmt, BUFF255, "'");
					strcat_s((char *) SQLStmt, BUFF255, element);
					strcat_s((char *) SQLStmt, BUFF255, "'");
					// Prepare And Execute The SQL Statement
					rc = SQLExecDirect(Example.StmtHandle, SQLStmt, SQL_NTS);
					// Display The Results Of The SQL Query
					if (rc == SQL_SUCCESS)
						Example.ShowResults(element);
				}
			}
			// Free The SQL Statement Handle
			if (Example.StmtHandle != NULL)
				SQLFreeHandle(SQL_HANDLE_STMT, Example.StmtHandle);
		}
		// Disconnect From The Sample Database
		rc = SQLDisconnect(Example.ConHandle);
	}
	// Return To The Operating System
	return(rc);
}