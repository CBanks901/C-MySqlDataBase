﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
// Add Mysql Library
using MySql.Data.MySqlClient;

class DBConnect
{
    private MySqlConnection connection;     // establishes a database conection
    private string server;                  // localhost server
    private string database;                // Database that will be used
    private string uid;                     // MySqul username
    private string password;                // MySql Password

    // Constructor
    public DBConnect()
    {
        // Call the initalize method
        initialize();
        MessageBox.Show("Successfully Initlaized.");
    }

    // Handles program setup
    private void initialize()
    {
        server = "localhost";
        database = "tableinfo";
        uid = "root";
        password = "12345";
        string connectionString;
        connectionString = "SERVER=" + server + ";" + "DATABASE=" + database
            + ";" + "UID=" + uid + ";" + "PASSWORD=" + password + ";" + "Port=3306" + ";";
        connection = new MySqlConnection(connectionString);

        if (connection == null)
        {
            MessageBox.Show("Allocation failed.");
        }
        else
            MessageBox.Show("Allocation successful.");

        MessageBox.Show("Testing connection");
    }

    private bool OpenConnection()
    {
        try
        {
            connection.Open();
            MessageBox.Show("Connection Established.");
            return true;
        }

        catch (MySqlException ex)
        {
            // attempt to catch a exception error:
            // if the ex.Number is zero then it can't connect to a server,
            // otherwise if 1045 the username or password is invalid

            switch (ex.Number)
            {
                case 0:
                    MessageBox.Show("Cannot connect to server. Contact administrator.");
                    break;

                case 1045:
                    MessageBox.Show("Invalid username/password, please try again.");
                    break;
            }

            MessageBox.Show("Connection can't be opened.");
            return false;
        }
    }

    private bool CloseConnection()
    {
        try
        {
            connection.Close();
            return true;
        }

        catch (MySqlException ex)
        {
            MessageBox.Show(ex.Message);
            return false;
        }
    }

    public void Insert()
    {
        MessageBox.Show("Insert Called!");
        Console.WriteLine("Please enter a name and age to add to the database.\n");

        Console.WriteLine("Format is as follows: \n ('First name last name', 'age').\n");
        string query = "INSERT INTO tableinfo (name, age) VALUES"
        + Console.ReadLine();           // gather the values from the user


        // attempt to open the connection
        if (this.OpenConnection() == true)
        {
            // Create a MySql command and assign the query and connection from the constructor
            MySqlCommand cmd = new MySqlCommand(query, connection);

            // Execute the command
            cmd.ExecuteNonQuery();

            // afterwords close the conection
            this.CloseConnection();

            MessageBox.Show("Successfully inserted into the table");
        }
    }

    public void Update()
    {
        MessageBox.Show("Update called!");
        Console.WriteLine("Please specify the name you want to use followed by the age and then the original name.\n");
        Console.WriteLine("Press enter each time and also use full names if inserted.\n");
        Console.WriteLine("For example: 'Chris', '22', 'Christian Banks'\n");
        string replacement, age, current;

        replacement = Console.ReadLine();
        age = Console.ReadLine();
        current = Console.ReadLine();
        string query = "UPDATE tableinfo SET name=" +
            replacement + "," + "age=" + age + "WHERE name=" + current;

        // open the connection
        if (this.OpenConnection() == true)
        {
            // create a mysql cmd
            MySqlCommand cmd = new MySqlCommand();

            // assign the query using Commandtext
            cmd.CommandText = query;

            // Set the cmd connection using connection
            cmd.Connection = connection;

            // Execute the query
            cmd.ExecuteNonQuery();

            MessageBox.Show("Update Successful!");
            // End the connection
            this.CloseConnection();
        }
    }

    public void Delete()
    {
        MessageBox.Show("Delete Called!");
        Console.WriteLine("Please enter a name to delete from the table. Format is as follows:\n");
        Console.WriteLine("'First name Last name'\n");
        string query = "DELETE FROM tableinfo WHERE name="
        + Console.ReadLine();   // query input from the user

        if (this.OpenConnection() == true)
        {
            MySqlCommand cmd = new MySqlCommand(query, connection);
            cmd.ExecuteNonQuery();
            this.CloseConnection();
        }
    }

    public List<string>[] Select()
    {
        string query = "SELECT * FROM tableinfo";

        // create a list to store the result
        List<string>[] list = new List<string>[3];
        list[0] = new List<string>();
        list[1] = new List<string>();
        list[2] = new List<string>();

        // Open up the connection
        if (this.OpenConnection() == true)
        {
            // Create a command
            MySqlCommand cmd = new MySqlCommand(query, connection);

            // create a data reader to and execute the command
            MySqlDataReader dataReader = cmd.ExecuteReader();

            // Read the data and store them in the list
            while (dataReader.Read())
            {
                list[0].Add(dataReader["id"] + "");
                list[1].Add(dataReader["name"] + "");
                list[2].Add(dataReader["age"] + "");
            }

            // close the data reader
            dataReader.Close();

            // end the connection
            this.CloseConnection();

            return list;
        }
        else
        {
            return list;
        }
    }

    public int Count()
    {
        string query = "SELECT COUNT(*) FROM tableinfo";
        int Count = -1;

        if (this.OpenConnection() == true)
        {
            // Create a MySql command
            MySqlCommand cmd = new MySqlCommand(query, connection);

            // Parses only a single value
            Count = int.Parse(cmd.ExecuteScalar() + "");

            MessageBox.Show("Count() called.");
            // close the connection
            this.CloseConnection();

            return Count;
        }
        else
        {
            return Count;
        }
    }

}

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            DBConnect m_DB = new DBConnect();

            Console.Write("Please choose a category: \n");
Console.Write("A to add to the database, D to delete from the database, U to replace a current name, S to select, or Q to quit\n");

            string option;
            option = Console.ReadLine();

            switch (option)
            {
                case "A":
                    m_DB.Insert();
                    break;
                case "D":
                    m_DB.Delete();
                    break;
                case "Q":
                    Console.WriteLine("Q chosen, exiting program.\n");
                    break;
                case "U":
                    m_DB.Update();
                    break;
            }

            
        }
    }
}
